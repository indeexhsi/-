'use strict';

angular.module('landlordReviewApp')
  .config(function($stateProvider) {
    $stateProvider
      .state('404', {
        url: '/404',
        templateUrl: 'app/error/error.html',
        controller: 'ErrorController'
      });
  });
