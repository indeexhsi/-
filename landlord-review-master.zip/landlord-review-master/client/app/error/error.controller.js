'use strict';

angular.module('landlordReviewApp')
  .controller('ErrorController', function($scope) {
    $scope.message = "The property you were looking for could not be found :(";
  });
