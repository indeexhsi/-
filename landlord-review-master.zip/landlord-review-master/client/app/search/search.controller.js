'use strict';

angular.module('landlordReviewApp')
  .controller('SearchController', function ($scope, $state, $stateParams, postcodeResults, apiResults, postcodeService, reviewModal) {
    $scope.postcode = $stateParams.postcode;
    $scope.results = postcodeService.mergeApiWithLookupResults(postcodeResults, apiResults);

    $scope.goToResult = function(property) {
      if(property.id) {
        $state.go('property', {id: property.id})
      } else {
        property.postcode = $scope.postcode;
        reviewModal.open(property);
      }
    }
  });
