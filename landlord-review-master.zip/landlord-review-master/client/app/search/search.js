'use strict';

angular.module('landlordReviewApp')
  .config(function($stateProvider) {
    $stateProvider
      .state('search', {
        url: '/search/:postcode',
        templateUrl: 'app/search/search.html',
        controller: 'SearchController',
        resolve: {
          postcodeResults: function(postcodeService, $stateParams, Postcode) {
            return Postcode.get({postcode: $stateParams.postcode}).$promise
                .then(function(data) {
                  return data;
                });
          },
          apiResults: function(postcodeResults, $http, $stateParams, Property) {
            return Property.getByPostcode({postcode: $stateParams.postcode}).$promise;
          }
        }
      });
  });
