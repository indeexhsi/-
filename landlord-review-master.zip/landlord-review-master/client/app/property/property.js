'use strict';

angular.module('landlordReviewApp')
  .config(function($stateProvider) {
    $stateProvider
      .state('property', {
        url: '/property/:id',
        templateUrl: 'app/property/property.html',
        controller: 'PropertyController',
        resolve: {
          property: function($http, $stateParams, Property) {
            return Property.get({id: $stateParams.id}).$promise;
          }
        }
      });
  });
