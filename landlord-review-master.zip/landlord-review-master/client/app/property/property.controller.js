'use strict';

angular.module('landlordReviewApp')
  .controller('PropertyController', function ($scope, property, Auth, Review) {
    $scope.property = property.property;
    $scope.reviews = property.reviews;
    $scope.getCurrentUser = Auth.getCurrentUser;

    //$scope.deleteCurrentUserComment = function(review) {
    //  Review.delete({id: review._id}).$promise
    //    .then(function() {
    //      $scope.reviews.splice($scope.reviews.indexOf(review), 1);
    //    });
    //};

    $scope.submitReview = function() {
      $scope.form.propertyId = $scope.property._id;
      Review.save($scope.form).$promise
        .then(function(result) {
          $scope.reviews.push(result);
        });
    };
  });
