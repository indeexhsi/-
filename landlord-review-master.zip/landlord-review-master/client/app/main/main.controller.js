'use strict';
angular.module('landlordReviewApp')
  .controller('MainController', function ($scope, $state) {
  $scope.searchForPostcode = function(postcode) {
    if(postcode !== '') {
      postcode = postcode.replace(/\s/g, '');
      $state.go('search', {postcode: postcode});
    }
  };
});
