'use strict';

angular.module('landlordReviewApp')
  .config(function($stateProvider) {
    $stateProvider
      .state('account.details', {
        url: '/details',
        authenticate: true,
        templateUrl: 'app/account/details/details.html',
        controller: 'accountDetailsController'
      });
  });
