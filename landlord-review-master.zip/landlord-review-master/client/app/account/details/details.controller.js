"use strict";

angular.module("landlordReviewApp")
  .controller("accountDetailsController", function() {

  });
