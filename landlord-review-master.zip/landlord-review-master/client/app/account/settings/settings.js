//'use strict';
//
//angular.module('landlordReviewApp')
//  .config(function($stateProvider) {
//    $stateProvider
//      .state('account.settings', {
//        url: '/settings',
//        templateUrl: 'app/account/settings/settings.html',
//        controller: 'accountSettingsController'
//      });
//  });
