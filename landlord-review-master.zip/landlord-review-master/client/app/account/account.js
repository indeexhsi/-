'use strict';

angular.module('landlordReviewApp')
  .config(function($stateProvider) {
    $stateProvider
      .state('account', {
        url: '/me',
        templateUrl: 'app/account/account.html',
        controller: 'accountController',
        authenticate: true
      });
  })
  .run(function($rootScope, $state) {
    $rootScope.$on('$stateChangeStart', function(event, next, nextParams, current) {
      if (next.name === 'logout' && current && current.name && !current.authenticate) {
        next.referrer = current.name;
      }

      if(next.name === 'account') {
        event.preventDefault();
        $state.go('account.details');
      }
    });
  });
