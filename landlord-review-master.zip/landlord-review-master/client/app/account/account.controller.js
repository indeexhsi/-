"use strict";

angular.module("landlordReviewApp")
  .controller("accountController", function() {

  });
