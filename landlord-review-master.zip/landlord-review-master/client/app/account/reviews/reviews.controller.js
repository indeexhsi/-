"use strict";

angular.module("landlordReviewApp")
  .controller("accountReviewsController", function($scope, $state, reviews) {
    $scope.reviews = reviews;
  });
