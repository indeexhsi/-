'use strict';

angular.module('landlordReviewApp')
  .config(function($stateProvider) {
    $stateProvider
      .state('account.reviews', {
        url: '/reviews',
        templateUrl: 'app/account/reviews/reviews.html',
        controller: 'accountReviewsController',
        resolve: {
          reviews: function(Review, Auth) {
            return Review.getForUser({id: Auth.getCurrentUser()._id}).$promise;
          }
        }
      });
  });
