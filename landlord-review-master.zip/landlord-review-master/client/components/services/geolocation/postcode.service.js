'use strict';

angular.module('landlordReviewApp')
  .service('postcodeService', function() {
    return {
      mergeApiWithLookupResults: function(postcodeLookupResults, apiResults) {
        angular.forEach(postcodeLookupResults, function(lookupResult) {
          angular.forEach(apiResults, function(apiResult) {
            if(apiResult.address1 === lookupResult.address1) {
              lookupResult.reviewCount = apiResult.reviewCount;
              lookupResult.id = apiResult._id;
            }
          })
        });

        return postcodeLookupResults;
      }
    }
  });
