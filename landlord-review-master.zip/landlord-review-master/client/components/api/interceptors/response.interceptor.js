"use strict";

angular.module('landlordReviewApp')
  .factory('responseInterceptor', function($q, $injector) {
    var state;
    return {
      responseError: function(response) {
        switch(response.status) {
          case 404:
            (state || (state = $injector.get('$state'))).go('404');
            break;
        }
        return $q.reject(response);
      }
    };
  });
