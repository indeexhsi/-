"use strict";

angular.module('landlordReviewApp')
  .factory('authInterceptor', function($rootScope, $q, $cookies, $injector) {
    var loginModal,
      $http;
    return {
      // Add authorization token to headers
      request: function(config) {
        config.headers = config.headers || {};
        if ($cookies.get('token') && config.url.indexOf('http') === -1) {
          config.headers.Authorization = 'Bearer ' + $cookies.get('token');
        }
        return config;
      },

      // Intercept 401s and open login modal
      responseError: function(response) {
        if(response.status === 401) {
          $cookies.remove('token');

          (loginModal || (loginModal = $injector.get('loginModal')));
          return loginModal.open()
            .then(function() {
              ($http || ($http = $injector.get('$http')));
              return $http(response.config);
            })
        }
        return $q.reject(response);
      }
    };
  });
