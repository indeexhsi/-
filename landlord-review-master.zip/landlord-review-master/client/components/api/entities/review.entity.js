'use strict';

angular.module('landlordReviewApp')
  .factory('Review', function($resource) {
    return $resource('/api/review/:id',
      {id: '@id'}, {
        getForUser: {
          method: 'GET',
          url: '/api/review/user/:id',
          params: {id: '@id'},
          isArray: true
        }
      });
  });
