var mockData = {
  'KT229DT': {
    "Latitude": 51.284241,
    "Longitude": -0.349517,
    "Addresses": [
      [
        "1 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "11 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "16 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "18 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "2 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "20 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "3 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "5 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "6 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "7 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "8 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ],
      [
        "9 The Beeches",
        "",
        "",
        "Fetcham, Leatherhead",
        "Surrey"
      ]
    ]
  },
  'SW153NF': {
    "Latitude": 51.453245,
    "Longitude": -0.222526,
    "Addresses": [
      [
        "Flat 1",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 10",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 11",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 12",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 2",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 3",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 4",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 5",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 6",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 7",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 8",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ],
      [
        "Flat 9",
        "Armstrong House",
        "Manor Fields",
        "London",
        "Greater London"
      ]
    ]
  }
};


"use strict";

angular.module('landlordReviewApp')
  .factory('Postcode', function($resource) {
    return {
      get: function(postcodeObj) {
        var postcode = postcodeObj.postcode;
        return {
          $promise: {
            then: function() {
              return mockData[postcode].Addresses.map(function(val) {
                return {
                  house_number: parseInt(/(\d+)/.exec(val[0])[0]),
                  address1: val[0],
                  address2: val[1],
                  address3: val[2],
                  address4: val[3].split(', ')[0],
                  town: val[3].split(', ')[1],
                  county: val[4],
                  country: 'UK'
                };
              });
            }
          }
        }
      }
    }



    //return $resource('https://api.getAddress.io/v2/uk/:postcode',
    //  {postcode: '@postcode', format: true, 'api-key': 'PAVHJj93NEelFtf29qwtOQ2411'}, {
    //    get: {
    //      method: 'GET',
    //      isArray: true,
    //      cache : true,
    //      transformResponse: function(data) {
    //        data = angular.fromJson(data);
    //
    //        return data.Addresses.map(function(val) {
    //          return {
    //            house_number: parseInt(/(\d+)/.exec(val[0])[0]),
    //            address1: val[0],
    //            address2: val[1],
    //            address3: val[2],
    //            address4: val[3].split(', ')[0],
    //            town: val[3].split(', ')[1],
    //            county: val[4],
    //            country: 'UK'
    //          };
    //        });
    //      }
    //    }
    //  }
    //);
  });
