'use strict';

angular.module('landlordReviewApp')
  .factory('Property', function($resource) {
    return $resource('/api/property/:id',
      {id: '@id'}, {
        getByPostcode: {
          method: 'GET',
          url: '/api/property/getByPostcode/:postcode',
          params: {postcode: '@postcode'},
          isArray: true
        }
      });
  });
