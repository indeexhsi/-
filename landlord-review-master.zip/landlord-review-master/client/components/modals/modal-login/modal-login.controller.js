'use strict';

angular.module('landlordReviewApp')
  .controller('loginModalController', function($scope, $state, Auth, loginModal, signupModal) {
    $scope.user = {};
    $scope.errors = {};
    $scope.loggingIn = false;

    $scope.openSignupModal = function() {
      signupModal.open()
        .then(function() {
          loginModal.close();
        });
    };

    $scope.login = function() {
      $scope.loggingIn = true;

      Auth.login($scope.user)
        .then(function() {
          $scope.loggingIn = false;
          loginModal.close();
        });
    };
  });
