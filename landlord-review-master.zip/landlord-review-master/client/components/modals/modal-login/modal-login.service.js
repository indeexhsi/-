'use strict';

angular.module('landlordReviewApp')
  .service('loginModal', function($rootScope, modalService) {
    var modal;
    return {
      open: function() {
        modal = modalService.open({
          title: 'Login',
          templateUrl: 'components/modals/modal-login/modal-login.html'
        });
        return modal.result;
      },
      close: function() {
        modal.close();
      }
    }
  });
