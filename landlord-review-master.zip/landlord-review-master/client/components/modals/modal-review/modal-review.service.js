'use strict';

angular.module('landlordReviewApp')
  .service('reviewModal', function($rootScope, modalService) {
    var modal;
    return {
      open: function(property) {
        modal = modalService.open({
          title: 'Leave a Review',
          templateUrl: 'components/modals/modal-review/modal-review.html',
          property: property
        });
        return modal.result;
      },
      close: function() {
        modal.close();
      }
    }
  });
