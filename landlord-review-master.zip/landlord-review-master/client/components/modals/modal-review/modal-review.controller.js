'use strict';

angular.module('landlordReviewApp')
  .controller('reviewModalController', function($scope, $state, reviewModal, Property, Review) {
    $scope.formData = {
      propertyManager: 'Tom Halley',
      rating: 3,
      reviewBody: 'Test',
      tenancyStart: '01/12/2014',
      tenancyEnd: '01/05/2015',
      rent: '500'
    };

    $scope.selectedRentType = 'Weekly';
    $scope.setRentalInterval = function(rentalInterval) {
      $scope.selectedRentType = rentalInterval;
    };

    $scope.submit = function() {
      Property.save($scope.property).$promise
        .then(function(result) {
          $scope.formData.propertyId = result._id;
          return Review.save($scope.formData).$promise
            .then(function() {
              return result._id;
            });
        })
        .then(function(propertyId) {
          reviewModal.close();
          $state.go('property', {id: propertyId})
        });
    };
  });
