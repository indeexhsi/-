'use strict';

angular.module('landlordReviewApp')
  .controller('signupModalController', function($scope, Auth, $state, loginModal, signupModal) {
    $scope.user = {};
    $scope.errors = {};

    $scope.switchToLogin = function() {
      loginModal.open()
        .then(function() {

        });
    };

    $scope.register = function() {
      Auth.createUser({
          name: $scope.user.name,
          email: $scope.user.email,
          password: $scope.user.password
        })
        .then(function() {
          // Account created, redirect to home
          signupModal.close();
        })
        .catch(function(err) {
          err = err.data;
          $scope.errors = {};

          // Update validity of form fields that match the mongoose errors
          angular.forEach(err.errors, function(error, field) {
            form[field].$setValidity('mongoose', false);
            $scope.errors[field] = error.message;
          });
        });
    };
  });
