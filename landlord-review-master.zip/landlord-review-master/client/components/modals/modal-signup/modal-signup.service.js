'use strict';

angular.module('landlordReviewApp')
  .service('signupModal', function($rootScope, modalService) {
    var modal;
    return {
      open: function() {
        modal = modalService.open({
          title: 'Sign up',
          templateUrl: 'components/modals/modal-signup/modal-signup.html'
        });
        return modal.result;
      },
      close: function() {
        modal.close();
      }
    }
  });
