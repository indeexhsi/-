'use strict';

angular.module("landlordReviewApp")
  .service('modalService', function($modal, $rootScope) {
    var self = this;

    var modalInstance;
    var scope = $rootScope.$new(true);

    self.open = function(config) {
      angular.extend(scope, config);

      modalInstance = modalInstance || $modal.open({
        templateUrl: 'components/modals/modal/modal.html',
        controller: 'modalController',
        scope: scope
      });

      modalInstance.result
        .then(function() {
          modalInstance = false;
        })
        .catch(function() {
          modalInstance = false;
        });

      return modalInstance;
    };

    self.close = function() {
      if(modalInstance) {
        modalInstance.close();
        modalInstance = false;
      }
    };
  });
