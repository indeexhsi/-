'use strict';

angular.module("landlordReviewApp")
  .controller('modalController', function($scope) {

  });
