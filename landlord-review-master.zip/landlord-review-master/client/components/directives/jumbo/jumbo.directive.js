'use strict';

angular.module('landlordReviewApp')
  .directive('jumbo', function () {
    return {
      templateUrl: 'components/directives/jumbo/jumbo.html',
      transclude: true,
      restrict: 'E'
    };
  });
