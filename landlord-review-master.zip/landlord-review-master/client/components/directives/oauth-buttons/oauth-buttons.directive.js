'use strict';

angular.module('landlordReviewApp')
  .directive('oauthButtons', function() {
    return {
      templateUrl: 'components/directives/oauth-buttons/oauth-buttons.html',
      restrict: 'EA',
      controller: 'OauthButtonsCtrl',
      controllerAs: 'OauthButtons',
      scope: {
        classes: '@'
      }
    };
  });
