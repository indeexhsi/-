'use strict';

angular.module('landlordReviewApp')
  .directive('tenancyDatepicker', function () {
    return {
      templateUrl: 'components/directives/datepicker/datepicker.html',
      controller: 'tenancyDatepicker',
      restrict: 'E',
      replace: true,
      scope: {
        ngModel: "=",
        label: "@",
        required: "@"
      }
    };
  });
