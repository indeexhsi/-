"use strict";

angular.module('landlordReviewApp')
  .controller('tenancyDatepicker', function($scope) {
    $scope.isOpen = false;
    $scope.dateOptions = {};
  });
