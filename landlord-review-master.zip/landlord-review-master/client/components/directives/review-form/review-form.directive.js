'use strict';

angular.module('landlordReviewApp')
  .directive('reviewForm', function () {
    return {
      templateUrl: 'components/directives/review-form/review-form.html',
      restrict: 'E',
      controller: 'reviewFormController',
      scope: {
        submitCallback: '&',
        formData: '='
      }
    };
  });
