'use strict';

angular.module('landlordReviewApp')
  .controller('reviewFormController', function ($scope, $http) {
    $scope.formData = {
      propertyManager: 'Tom Halley',
      rating: 3,
      reviewBody: 'Test',
      tenancyStart: '01/12/2014',
      tenancyEnd: '01/05/2015',
      rent: '500'
    };

    $scope.selectedRentType = 'Weekly';
    $scope.setRentalInterval = function(rentalInterval) {
      $scope.selectedRentType = rentalInterval;
    };

    $scope.submit = function() {
      if(!$scope.addReview.$valid) {
        return false;
      }

      $scope.submitCallback();
    };

    //$scope.submitReview = function() {
    //  $scope.review.propertyId = $scope.property._id;
    //  $http.post('/api/review', $scope.review);
    //};
  });
