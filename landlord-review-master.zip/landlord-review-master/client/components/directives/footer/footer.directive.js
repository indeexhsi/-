'use strict';

angular.module('landlordReviewApp')
  .directive('footer', function () {
    return {
      templateUrl: 'components/directives/footer/footer.html',
      restrict: 'E',
      link: function (scope, element) {
        element.addClass('footer');
      }
    };
  });
