'use strict';

angular.module('landlordReviewApp')
  .controller('NavbarCtrl', function ($scope, Auth, loginModal, signupModal) {
    $scope.menu = [];

    $scope.isCollapsed = true;
    $scope.isLoggedIn = Auth.isLoggedIn;
    $scope.isAdmin = Auth.isAdmin;
    $scope.getCurrentUser = Auth.getCurrentUser;
    $scope.logout = Auth.logout;

    $scope.openLoginModal = loginModal.open;
    $scope.openSignupModal = signupModal.open;
  });
