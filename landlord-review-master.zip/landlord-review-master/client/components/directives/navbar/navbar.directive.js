'use strict';

angular.module('landlordReviewApp')
  .directive('navbar', function () {
    return {
      templateUrl: 'components/directives/navbar/navbar.html',
      restrict: 'E',
      controller: 'NavbarCtrl'
    };
  });
