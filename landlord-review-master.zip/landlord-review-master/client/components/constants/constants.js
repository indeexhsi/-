"use strict";

angular.module('landlordReviewApp')
  .factory('constants', function() {
    return {
      POSTCODE: {
        API_KEY: 'PAVHJj93NEelFtf29qwtOQ2411'
      }
    }
  });
