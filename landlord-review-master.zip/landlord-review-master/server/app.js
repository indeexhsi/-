/**
 * Main application file
 */

'use strict';

import express from 'express';
import mongoose from 'mongoose';
import config from './config/environment';
import http from 'http';

// Connect to MongoDB
mongoose.connect(config.mongo.uri, config.mongo.options);
mongoose.connection.on('error', function(err) {
  console.error('MongoDB connection error: ' + err);
  process.exit(-1);
});

// Populate databases with sample data
if (config.seedDB) {
  var fixtures = require('../node_modules/pow-mongodb-fixtures/src/index').connect(config.mongo.uri);
  fixtures.clearAllAndLoad('./config/seed.js', function() {
    console.log('fixtures loaded');
  });
}

if(config.runSwagger) {
  var swagger_app = express().use(express.static(__dirname + '/swagger'));
  var swagger_server = http.createServer(swagger_app);
  swagger_server.listen(8080, 'localhost', function() {
    console.log('Swagger server running');
  })
}

// Setup server
var app = express();
var server = http.createServer(app);
require('./config/express')(app);
require('./routes')(app);

// Start server
function startServer() {
  server.listen(config.port, config.ip, function() {
    console.log('Express server listening on %d, in %s mode', config.port, app.get('env'));
  });
}

setImmediate(startServer);

// Expose app
exports = module.exports = app;
