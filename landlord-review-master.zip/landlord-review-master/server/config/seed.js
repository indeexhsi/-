/**
 * Populate DB with sample data on server start
 * to disable, edit config/environment/index.js, and set `seedDB: false`
 */

'use strict';
var shortid = require('shortid');

var users = exports.users = {
  user1: {
    _id: shortid.generate(),
    salt: 'WfrLH+UgRks5Ei3s3q22Aw==',
    provider: 'local',
    name: 'Test User',
    email: 'test@example.com',
    password: '2eTb3mSA9uvtl3pIH2HLlzNlGmqrZES8VLcE7DqLMyqHEocPyB5VHLgm2mzwhMeqlar0iHbm0uNO6w+rkovKKA==',
    role: 'user'
  },
  user2: {
    _id: shortid.generate(),
    salt: 'O08vRiigAL0F0QRMsLZiBQ==',
    provider: 'local',
    name: 'Admin',
    email: 'admin@example.com',
    password: '9jvFEc/P0PoUUMH/Ou5QAHYgfjA93Frj+urdxGBJrV8INPwYN84WsHD+/lo7ZSJmNZH1CW8yWso960KfI8Qhdg==',
    role: 'admin'
  }
};

var properties = {
  property1: {
    _id: shortid.generate(),
    address1: '16 The Beeches',
    address2: 'Fetcham',
    town: 'Leatherhead',
    postcode: 'KT229DT',
    county: 'Surrey',
    country: 'UK'
  }
};

var landlords = {
  landlord1: {
    _id: shortid.generate(),
    name: "Himal",
    properties: [properties.property1._id]
  }
};

var reviews = {
  review1: {
    _id: shortid.generate(),
    property_owner: 'Tom Halley',
    body: 'Really great house, great landlord',
    rating: 5,
    tenancy_start: '01/01/2014',
    tenancy_end: '01/01/2015',
    user: users.user1._id,
    property: properties.property1._id
  }
};

exports.reviews = reviews;
exports.properties = properties;
exports.landlords = landlords;
exports.users = users;
