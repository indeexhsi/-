/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /api/things              ->  index
 * POST    /api/things              ->  create
 * GET     /api/things/:id          ->  show
 * PUT     /api/things/:id          ->  update
 * DELETE  /api/things/:id          ->  destroy
 */

'use strict';

import _ from 'lodash';
import Landlord from './landlord.model';
import Controller from '../../components/common/common.controller.js'

class LandlordController extends Controller {
  index(req, res) {
    Landlord.findAsync()
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  };

  show(req, res) {
    Landlord.findByIdAsync(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  };

  create(req, res) {
    Landlord.createAsync(req.body)
      .then(super.responseWithResult(res, 201))
      .catch(super.handleError(res));
  };

  update(req, res) {
    if (req.body._id) {
      delete req.body._id;
    }
    Landlord.findByIdAsync(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(saveUpdates(req.body))
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  };

  destroy(req, res) {
    Landlord.findByIdAsync(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(removeEntity(res))
      .catch(super.handleError(res));
  };
}

module.exports = new LandlordController();
