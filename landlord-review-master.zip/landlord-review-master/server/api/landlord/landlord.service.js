/**
 * Created by tom on 30/11/15.
 */

import Landlord from './landlord.model';

class LandlordService {
  getLandlordsForProperty(id) {
    return Landlord.findAsync({properties: {$in: [id]}}, '_id name');
  };
}

module.exports = new LandlordService();
