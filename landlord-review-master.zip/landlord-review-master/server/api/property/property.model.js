'use strict';

var mongoose = require('bluebird').promisifyAll(require('mongoose'));
var Schema = mongoose.Schema;
var shortid = require('shortid');

var PropertySchema = new Schema({
  _id: {type: String, unique: true, 'default': shortid.generate},
  address1: String,
  address2: String,
  address3: String,
  address4: String,
  postcode: String,
  town: String,
  county: String,
  country: String
});

module.exports = mongoose.model('Property', PropertySchema);

