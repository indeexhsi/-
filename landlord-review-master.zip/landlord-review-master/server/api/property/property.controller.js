/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /api/things              ->  index
 * POST    /api/things              ->  create
 * GET     /api/things/:id          ->  show
 * PUT     /api/things/:id          ->  update
 * DELETE  /api/things/:id          ->  destroy
 */

'use strict';

import _ from 'lodash';
import PropertyService from './property.service';
import Controller from '../../components/common/common.controller.js'

class PropertyController extends Controller {
  getByPostcode(req, res) {
    var postcode = req.params.postcode;
    postcode = postcode.toUpperCase();
    postcode = postcode.replace(/\s/g, '');

    PropertyService.getPropertiesSearch(postcode)
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  }

  show(req, res) {
    PropertyService.getFullProperty(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  };

  create(req, res) {
    PropertyService.createProperty(req.body)
      .then(super.responseWithResult(res, 201))
      .catch(super.handleError(res));
  };

  update(req, res) {
    if (req.body._id) {
      delete req.body._id;
    }
    PropertyService.getProperty(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(saveUpdates(req.body))
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  };

  destroy(req, res) {
    PropertyService.getProperty(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(removeEntity(res))
      .catch(super.handleError(res));
  };
}

module.exports = new PropertyController();
