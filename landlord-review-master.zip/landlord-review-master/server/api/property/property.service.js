/**
 * Created by tom on 25/11/15.
 */

import Q from 'q';
import Property from "./property.model";
import ReviewService from "../review/review.service";
import LandlordService from "../landlord/landlord.service";

class PropertyService {
  getFullProperty(propertyId) {
    var returnObj = {};

    return Property.findOneAsync({_id: propertyId})
      .then(function(property) {
        returnObj.property = property;
      })
      .then(function() {
        return ReviewService.getReviewsForProperty(propertyId)
      })
      .then(function(reviews) {
        returnObj.reviews = reviews;
      })
      .then(function() {
        return LandlordService.getLandlordsForProperty(propertyId);
      })
      .then(function(landlords) {
        returnObj.landlords = landlords;
        return returnObj;
      })
      .catch(function(err) {
        console.log(err);
      });
  }

  getPropertiesSearch(postcode) {
    var propertiesObj;
    var propertyIds = [];

    return Property.findAsync({postcode: postcode}, '_id address1 town postcode')
      .then(function(properties) {
        propertyIds = properties.map(function(property) {
          return property._id;
        });
        propertiesObj = properties;
      })
      .then(function() {
        return ReviewService.getReviewCountForProperties(propertyIds);
      })
      .then(function(reviewCounts) {
        var properties = [];
        propertiesObj.forEach(function(property) {
          property = property.toObject();
          property.reviewCount = reviewCounts.filter(function(reviewSet) {
            return reviewSet._id == property._id;
          })[0].reviewCount;
          properties.push(property);
        });
        return properties;
      });
  }

  createProperty(data) {
    return Property.createAsync(data)
  }
}

module.exports = new PropertyService();
