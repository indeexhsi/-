'use strict';

import _ from 'lodash';
import Review from './review.model';
import ReviewService from './review.service';
import AuthService from '../../auth/auth.service';
import Controller from "../../components/common/common.controller";

class ReviewController extends Controller {
  index(req, res) {
    Review.findAsync()
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  };

  show(req, res) {
    Review.findByIdAsync(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  };

  getByPropertyId(req, res) {
    ReviewService.getReviewsForProperty(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  }

  getByUserId(req, res) {
    ReviewService.getReviewsForUser(req.params.id)
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  }

  create(req, res) {
    ReviewService.createReview(
      req.body.propertyManager,
      req.body.reviewBody,
      req.body.rating,
      req.body.tenancyStart,
      req.body.tenancyEnd,
      req.body.rent,
      req.body.propertyId,
      req.user._id
    )
      .then(super.responseWithResult(res, 201))
      .catch(super.handleError(res));
  };

  update(req, res) {
    if (req.body._id) {
      delete req.body._id;
    }
    Review.findByIdAsync(req.params.id)
      .then(super.handleEntityNotFound(res))
      .then(saveUpdates(req.body))
      .then(super.responseWithResult(res))
      .catch(super.handleError(res));
  };

  destroy(req, res) {
    ReviewService.deleteReview(req.params.id, req.user._id)
      .then(super.handleEntityNotFound(res))
      .then(super.removeEntity(res))
      .catch(super.handleError(res));
  };
}

module.exports = new ReviewController();
