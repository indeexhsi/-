/**
 * Created by tom on 10/10/15.
 */
'use strict';

var express = require('express');
var controller = require('./review.controller');
import auth from '../../auth/auth.service';
var router = express.Router();

router.get('/', controller.index);
router.get('/:id', controller.show);
router.get('/property/:id', controller.getByPropertyId);
router.get('/user/:id', controller.getByUserId);
router.post('/', auth.isAuthenticated(), controller.create);
router.put('/:id', controller.update);
router.patch('/:id', controller.update);
router.delete('/:id', auth.isAuthenticated(), controller.destroy);

module.exports = router;
