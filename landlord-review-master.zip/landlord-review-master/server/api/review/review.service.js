"use strict";

import Review from './review.model';
import User from '../user/user.model';
import Q from 'q';
import Property from '../property/property.model';

class ReviewService {
  createReview(propertyOwner, body, rating, tenancyStart, tenancyEnd, rent, propertyId, userId) {
    var property;
    var user;

    return Review.findAsync({property: propertyId, user:userId})
      .then(function(reviews) {
        if(reviews.length !== 0) {
          throw Error("Review already exists for this user property")
        }
      })
      .then(function() {
        return Property.findByIdAsync(propertyId)
      })
      .then(function(propertyObj) {
        property = propertyObj;
      })
      .then(function() {
        return User.findByIdAsync(userId);
      })
      .then(function(userObj) {
        user = userObj;
      })
      .then(function() {
        return Review.createAsync({
          property_owner: propertyOwner,
          body: body,
          rating: rating,
          tenancy_start: tenancyStart,
          tenancy_end: tenancyEnd,
          rent: rent,
          property: property._id,
          user: user._id
        });
      });
  };

  getReviewCountForProperties(propertyIds) {
    var deferred = Q.defer();

    Review.aggregate([
      {$match: {
        property: { $in: propertyIds }
      }},
      {$group: {
        _id: '$property',
        reviewCount: { "$sum": 1 }
      }}
    ], function(err, result) {
      if(err) {
        deferred.reject(err)
      } else {
        deferred.resolve(result);
      }
    });

    return deferred.promise;
  }

  getReviewsForProperty(propertyId) {
    return Review.findAsync({property: propertyId}, '_id body property_owner rating tenancy_end tenancy_start user');
  };

  getReviewsForUser(userId) {
    return Review.findAsync({user: userId});
  }

  deleteReview(reviewId, userId) {
    return Review.findOneAsync({user: userId, _id: reviewId})
  }
}

module.exports = new ReviewService();
