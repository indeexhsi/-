'use strict';

var mongoose = require('bluebird').promisifyAll(require('mongoose'));
var Schema = mongoose.Schema;
var shortid = require('shortid');

var ReviewSchema = new Schema({
  _id: {type: String, unique: true, 'default': shortid.generate},
  property_owner: String,
  body: String,
  rating: Boolean,
  tenancy_start: String,
  tenancy_end: String,
  rent: Number,
  property: {type: String, ref: 'Property'},
  user: {type: String, ref: 'User'}
});

module.exports = mongoose.model('Review', ReviewSchema);

