/**
 * Created by tom on 11/10/15.
 */

class Controller {
  handleError(res, statusCode) {
    statusCode = statusCode || 500;
    return function(err) {
      console.log(err);
      res.status(statusCode).send(err);
    };
  };

  responseWithResult(res, statusCode) {
    statusCode = statusCode || 200;
    return function(entity) {
      if (entity) {
        res.status(statusCode).json(entity);
      }
    };
  };

  handleEntityNotFound(res) {
    return function(entity) {
      if (!entity || entity.length === 0) {
        res.status(404).end();
        return null;
      }
      return entity;
    };
  };

  saveUpdates(updates) {
    return function(entity) {
      var updated = _.merge(entity, updates);
      return updated.saveAsync()
        .spread(function(updated) {
          return updated;
        });
    };
  };

  removeEntity(res) {
    return function(entity) {
      if (entity) {
        return entity.removeAsync()
          .then(function() {
            res.status(204).end();
          });
      }
    };
  };
}

module.exports = Controller;
