declare module skins.components.buttons{
	class BtnCallSkin extends egret.gui.Skin{
	}
}
declare module skins.components.buttons{
	class BtnNoCallSkin extends egret.gui.Skin{
	}
}
declare module skins.components.buttons{
	class BtnNoRobSkin extends egret.gui.Skin{
	}
}
declare module skins.components.buttons{
	class BtnPassSkin extends egret.gui.Skin{
	}
}
declare module skins.components.buttons{
	class BtnPushSkin extends egret.gui.Skin{
	}
}
declare module skins.components.buttons{
	class BtnResetSkin extends egret.gui.Skin{
	}
}
declare module skins.components.buttons{
	class BtnRobSkin extends egret.gui.Skin{
	}
}
declare module skins.components.buttons{
	class BtnTipSkin extends egret.gui.Skin{
	}
}
declare module skins.components{
	class ClockSkin extends egret.gui.Skin{
	}
}
declare module skins.components.player{
	class PlayActionSkin extends egret.gui.Skin{
	}
}
declare module skins.components.player{
	class PlayerLeftSkin extends egret.gui.Skin{
	}
}
declare module skins.components.player{
	class PlayerRightSkin extends egret.gui.Skin{
	}
}
declare module skins.components.player{
	class PlayerSelfSkin extends egret.gui.Skin{
	}
}
declare module skins.scene{
	class HallSceneSkin extends egret.gui.Skin{
	}
}
declare module skins.scene{
	class RoomSceneSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class AlertSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class CheckBoxSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class CloseButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class DropDownListItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class DropDownListOpenButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class DropDownListSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class HScrollBarSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class HScrollBarThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class HSliderSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class HSliderThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ListSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class PanelSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ProgressBarSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class RadioButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ScrollerSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class SkinnableContainerSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class SkinnableDataContainer extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class SliderThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TabBarButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TabBarSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TextAreaSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TextInputSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TitleWindowSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ToggleButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class ToggleSwitchSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TreeDisclosureButtonSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TreeItemRendererSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class TreeSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class VScrollBarSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class VScrollBarThumbSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class VSliderSkin extends egret.gui.Skin{
	}
}
declare module skins.simple{
	class VSliderThumbSkin extends egret.gui.Skin{
	}
}
