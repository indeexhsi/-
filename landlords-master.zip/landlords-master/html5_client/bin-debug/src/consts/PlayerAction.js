var PlayerActionType = (function () {
    function PlayerActionType() {
    }
    return PlayerActionType;
})();
//# sourceMappingURL=PlayerAction.js.map