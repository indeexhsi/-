var RoomNoticeType = (function () {
    function RoomNoticeType() {
    }
    //玩家进入房间
    RoomNoticeType.PLAYER_ENTER_ROOM = "player_enter_room";
    //玩家准备好了
    RoomNoticeType.PLAYER_READY = "player_ready";
    //玩家退出了房间
    RoomNoticeType.PLAYER_EXIT_ROOM = "player_exit_room";
    return RoomNoticeType;
})();
//# sourceMappingURL=RoomNoticeType.js.map