var RoomScene = (function (_super) {
    __extends(RoomScene, _super);
    function RoomScene() {
        _super.call(this, skins.scene.RoomSceneSkin);
    }
    var __egretProto__ = RoomScene.prototype;
    return RoomScene;
})(ASkinCom);
RoomScene.prototype.__class__ = "RoomScene";
