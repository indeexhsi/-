var RobotMgr = (function () {
    function RobotMgr() {
    }
    return RobotMgr;
})();
//# sourceMappingURL=RobotManager.js.map