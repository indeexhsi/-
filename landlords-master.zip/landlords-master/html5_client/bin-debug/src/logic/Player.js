var Player = (function () {
    function Player(vo) {
    }
    return Player;
})();
//# sourceMappingURL=Player.js.map