//卡牌组合VO (Combination)
var CardCombinVO = (function () {
    function CardCombinVO() {
    }
    return CardCombinVO;
})();
//# sourceMappingURL=CardCombinationVO.js.map