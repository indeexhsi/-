var PlayerVO = (function () {
    function PlayerVO() {
        //ID
        this.id = "";
        //名称
        this.name = "";
        //金币数
        this.gold = 0;
        //性别
        this.sex = 0;
        //是否是AI
        this.isRobot = false;
    }
    return PlayerVO;
})();
//# sourceMappingURL=PlayerVO.js.map