var DC = (function () {
    function DC() {
    }
    var __egretProto__ = DC.prototype;
    return DC;
})();
DC.prototype.__class__ = "DC";
//# sourceMappingURL=DC.js.map