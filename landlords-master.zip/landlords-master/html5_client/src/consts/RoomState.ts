﻿class RoomState
{
    //空闲阶段
    public static FREE: number = 0;
    //叫地主阶段
    public static CALL_LANDLORD: number = 2;    
    //游戏中
    public static PLAY: number = 3;    
} 