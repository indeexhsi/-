﻿class PlayerActionType
{
    //叫地主
    public static CALL: number = 1;
    //不叫
    public static NO_CALL: number = 2;
    //抢地主
    public static ROB: number = 3;
    //不抢
    public static NO_ROB: number = 4;
    //不出
    public static PASS: number = 5;
    //出牌
    public static PUSH: number = 6;
}