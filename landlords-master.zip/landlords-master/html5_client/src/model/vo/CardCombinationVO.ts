﻿//卡牌组合VO (Combination)
class CardCombinVO
{
    //组合中卡牌的ID
    public cards: number[];
    //组合中卡牌在手牌中的位置
    public indexs: number[];
    //组合的分数
    public score: number;
} 