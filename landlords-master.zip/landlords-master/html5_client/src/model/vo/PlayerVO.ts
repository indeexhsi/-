﻿class PlayerVO
{
    //ID
    public id: string = "";
    //名称
    public name: string = "";
    //金币数
    public gold: number = 0;
    //性别
    public sex: number = 0;
    //是否是AI
    public isRobot: boolean = false;
} 