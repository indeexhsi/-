﻿class DC
{
    public static stage: egret.Stage;
    public static cfg: any;

}